<aside>
    <div id="sidebar" class="nav-collapse">
        <!-- sidebar menu start-->
        <div class="leftside-navigation">
            <ul class="sidebar-menu" id="nav-accordion">
                <li>
                    <a class="active" href="index.php">
                        <i class="fa fa-dashboard"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                <li class="sub-menu">
                    <a href="patients.php">
                        <i class="fa fa-plus-circle"></i>
                        <span>Patients</span>
                    </a>
                </li>

            </ul>            </div>
        <!-- sidebar menu end-->
    </div>
</aside>