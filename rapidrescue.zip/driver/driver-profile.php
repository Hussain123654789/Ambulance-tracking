<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');

// Check if driver is logged in
if (strlen($_SESSION['eahpaid'] == 0)) {
  header('location:logout.php');
} else {
  if (isset($_POST['submit'])) {
    $driverid = $_SESSION['eahpaid'];
    $dname = $_POST['drivername'];
    $mobno = $_POST['contactnumber'];
    $status = $_POST['status'];

    // Update driver profile
    $query = mysqli_query($con, "UPDATE tblambulance SET DriverName='$dname', DriverContactNumber='$mobno', Status='$status' WHERE ID='$driverid'");
    if ($query) {
      echo "<script>alert('Profile details updated successfully.');</script>";
      echo "<script type='text/javascript'> document.location = 'driver-profile.php'; </script>";
    } else {
      echo "<script>alert('Something went wrong. Please try again.');</script>";
    }
  }
?>

<!DOCTYPE html>
<head>
<title>EAHP || Driver Profile</title>
<!-- Bootstrap CSS -->
<link rel="stylesheet" href="css/bootstrap.min.css">
<!-- Custom CSS -->
<link href="css/style.css" rel="stylesheet" type="text/css">
<link href="css/style-responsive.css" rel="stylesheet" />
<link href="css/font-awesome.css" rel="stylesheet">
<script src="js/jquery2.0.3.min.js"></script>
</head>
<body>
<section id="container">
  <!-- Header -->
  <?php include_once('includes/header.php'); ?>
  <!-- Sidebar -->
  <?php include_once('includes/sidebar.php'); ?>
  <!-- Main Content -->
  <section id="main-content">
    <section class="wrapper">
      <div class="form-w3layouts">
        <div class="row">
          <div class="col-lg-12">
            <section class="panel">
              <header class="panel-heading">
                Driver Profile
              </header>
              <div class="panel-body">
                <div class="form">
                  <?php
                    $driverid = $_SESSION['eahpaid'];
                    $ret = mysqli_query($con, "SELECT * FROM tblambulance WHERE ID='$driverid'");
                    while ($row = mysqli_fetch_array($ret)) {
                  ?>
                  <form class="cmxform form-horizontal" method="post" action="">
                    <div class="form-group">
                      <label for="drivername" class="control-label col-lg-3">Driver Name</label>
                      <div class="col-lg-6">
                        <input class="form-control" id="drivername" name="drivername" type="text" value="<?php echo $row['DriverName']; ?>">
                      </div>
                    </div>

                    <div class="form-group">
                      <label for="contactnumber" class="control-label col-lg-3">Contact Number</label>
                      <div class="col-lg-6">
                        <input class="form-control" id="contactnumber" name="contactnumber" type="text" value="<?php echo $row['DriverContactNumber']; ?>" required>
                      </div>
                    </div>

                    <div class="form-group">
                      <label for="status" class="control-label col-lg-3">Status</label>
                      <div class="col-lg-6">
                        <select class="form-control" id="status" name="status">
                          <option value="Assigned" <?php if ($row['Status'] == 'Assigned') echo 'selected'; ?>>Assigned</option>
                          <option value="Pickup" <?php if ($row['Status'] == 'Pickup') echo 'selected'; ?>>Pickup</option>
                          <option value="Reached" <?php if ($row['Status'] == 'Reached') echo 'selected'; ?>>Reached</option>
                        </select>
                      </div>
                    </div>

                    <div class="form-group">
                      <div class="col-lg-offset-3 col-lg-6">
                        <button class="btn btn-primary" type="submit" name="submit">Update</button>
                      </div>
                    </div>
                  </form>
                  <?php } ?>
                </div>
              </div>
            </section>
          </div>
        </div>
      </div>
    </section>
  </section>
</section>

<!-- Scripts -->
<script src="js/bootstrap.js"></script>
<script src="js/jquery.dcjqaccordion.2.7.js"></script>
<script src="js/scripts.js"></script>
<script src="js/jquery.slimscroll.js"></script>
<script src="js/jquery.nicescroll.js"></script>
<script src="js/jquery.scrollTo.js"></script>
</body>
</html>
<?php } ?>
