<?php
session_start();
error_reporting(E_ALL); // Enable detailed error reporting
ini_set('display_errors', 1);

include('includes/dbconnection.php');

// Check if the session variable is set
if (strlen($_SESSION['eahpaid']) == 0) {
    header('location:logout.php');
    exit();
}

// Get ambulance registration number (In real usage, this could be passed via session or URL)

// Check database connection
if ($con->connect_error) {
    die("Database connection failed: " . $con->connect_error);
}

// If the form is submitted, update the status in the database
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_status'])) {
    $newStatus = $_POST['status'];
    $patientId = $_POST['patient_id']; // Assuming each patient has a unique ID

    $updateSql = "UPDATE tblambulancehiring SET Status = '$newStatus' WHERE id = '$patientId'";
    if ($con->query($updateSql) === TRUE) {
        echo "<script>alert('Status updated successfully');</script>";
    } else {
        echo "Error updating record: " . $con->error;
    }
}
$id = $_SESSION['eahpaid'];

// Prepare the first query to fetch the ambulance registration number
$query = "SELECT AmbRegNum FROM tblambulance WHERE ID = ?";
$stmt = $con->prepare($query);

if ($stmt) {
    $stmt->bind_param("s", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $driverAmbulanceRegNo = $row['AmbRegNum'];
    $stmt->close();

    // Fetch patients under this driver's ambulance
    $sql = "SELECT id, PatientName, RelativeName, RelativeConNum, Address, City, State, Status 
            FROM tblambulancehiring 
            WHERE AmbulanceRegNo = ?";

    $stmt2 = $con->prepare($sql);
    if ($stmt2) {
        $stmt2->bind_param("s", $driverAmbulanceRegNo);
        $stmt2->execute();
        $result2 = $stmt2->get_result();
    } else {
        echo "Error preparing statement: " . $con->error;
        exit();
    }
} else {
    echo "Error preparing statement: " . $con->error;
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patients in Custody</title>
    <!-- Include your Bootstrap and other styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link href="css/style.css" rel="stylesheet" type="text/css" />
    <link href="css/style-responsive.css" rel="stylesheet" />
    <link href="css/font-awesome.css" rel="stylesheet"> 
</head>
<body>
<?php include_once('includes/header.php'); ?>
<?php include_once('includes/sidebar.php'); ?>

<section id="main-content">
    <section class="wrapper">
        <div class="table-agile-info">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Patients in Driver's Custody
                </div>
                <div>
                    <table class="table table-bordered">
                        <thead class="thead-dark">
                            <tr>
                                <th>Patient Name</th>
                                <th>Relative Name</th>
                                <th>Contact Number</th>
                                <th>Address</th>
                                <th>City</th>
                                <th>State</th>
                                <th>Status</th>
                                <th>Update Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            if ($result->num_rows > 0) {
                                // Output data of each row
                                while($row = $result2->fetch_assoc()) {
                                    echo "<tr>
                                            <td>{$row['PatientName']}</td>
                                            <td>{$row['RelativeName']}</td>
                                            <td>{$row['RelativeConNum']}</td>
                                            <td>{$row['Address']}</td>
                                            <td>{$row['City']}</td>
                                            <td>{$row['State']}</td>
                                            <td>{$row['Status']}</td>
                                            <td>
                                                <form method='POST' action=''>
                                                    <input type='hidden' name='patient_id' value='{$row['id']}' />
                                                    <select name='status' class='form-control mb-2'>
                                                        <option value='Assigned' " . ($row['Status'] == 'Assigned' ? 'selected' : '') . ">Assigned</option>
                                                        <option value='Pickup' " . ($row['Status'] == 'Pickup' ? 'selected' : '') . ">Pickup</option>
                                                        <option value='Reached' " . ($row['Status'] == 'Reached' ? 'selected' : '') . ">Reached</option>
                                                        <option value='On the Way' " . ($row['Status'] == 'On the Way' ? 'selected' : '') . ">Reached</option>
                                                    </select>
                                                    <button type='submit' name='update_status' class='btn btn-primary mt-2'>Update</button>
                                                </form>
                                            </td>
                                          </tr>";
                                }
                            } else {
                                echo "<tr><td colspan='8'>No patients found</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>
</section>

<!-- Scripts -->
<script src="js/jquery2.0.3.min.js"></script>
<script src="js/bootstrap.js"></script>
</body>
</html>

<?php
$con->close();
?>
